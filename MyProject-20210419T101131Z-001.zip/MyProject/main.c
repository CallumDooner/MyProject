#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "ch.h"
#include "hal.h"
#include "memory_protection.h"
#include <main.h>
#include "leds.h"
#include "spi_comm.h"
#include "motors.h"
#include "sensors/proximity.h"
#include "chprintf.h"
#include "usbcfg.h"

#include "epuck1x/uart/e_uart_char.h"
#include "stdio.h"
#include "serial_comm.h"

int main(void)
{

    halInit();
    chSysInit();
    mpu_init();
    motors_init();
    usb_start();

    clear_leds();
    spi_comm_start();
    serial_start();
    proximity_start();
    calibrate_ir();

    int c;


    /* Infinite loop. */
    while (1) {

    	/* Selector Spinning Code (Task 2)

        for (c=0;c<get_selector();c++){

        	left_motor_set_speed(500);
        	right_motor_set_speed(-500);

        	set_body_led(2);
        	chThdSleepMilliseconds(250);
        	set_body_led(2);
        	chThdSleepMilliseconds(250);
        }
		for (c=0;c<get_selector();c++){

			left_motor_set_speed(-500);
			right_motor_set_speed(500);

			set_body_led(2);
		    chThdSleepMilliseconds(250);
		    set_body_led(2);
		    chThdSleepMilliseconds(250);
		}
		if (get_selector()==0){
			left_motor_set_speed(0);
			right_motor_set_speed(0);
		}

		*/
    	/* Task 3 (This is currently Incomplete)
    	chThdSleepMilliseconds(500);
    	c=0;
    	int prox_values[10];
    	for (c=0;c<get_calibrated_prox();c++){
    		prox_values[c] = get_calibrated_prox(c);
    	}

    	}
    	*/


    }
}

#define STACK_CHK_GUARD 0xe2dee396
uintptr_t __stack_chk_guard = STACK_CHK_GUARD;

void __stack_chk_fail(void)
{
    chSysHalt("Stack smashing detected");
}
